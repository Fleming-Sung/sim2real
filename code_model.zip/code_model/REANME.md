## Requirements

The main package and version of python environment are as follows

```
torch                     1.11.0+cu113         
python                    3.7.13
cloudpickle               2.0.0
cogenvdecoder             0.1.29
filelock                  3.6.0
grpcio                    1.44.0
gym                       0.20.0
gym-notices               0.0.6
gym-unity                 0.28.0
importlib-metadata        4.11.3
mlagents-envs             0.28.0
numpy                     1.21.2
opencv-python             4.5.5.64
opencv-contrib-python     4.5.5.64     
pettingzoo                1.12.0
pillow                    9.1.0
protobuf                  3.20.0
pyyaml                    6.0
six                       1.16.0
typing-extensions         4.1.1
zipp                      3.8.0
vc                        14.2           
vs2015_runtime            14.27.29016
matplotlib                3.5.2
```



## Usage

The project structure and intention are as fallows:

```
Submit_v1
	|----win_v1                         #simulation environment provided officially 
	|----code_model                     #the trained models and sorce code
		|----model_path                 #trained models for navigation and confrontation
			|----2_1_reward             #trained models for navigation
			|----shoot_policy           #trained models for confrontation
		|----cog_agent.py				#the trained agent for COG
		|----submit_test.py				#testing interface.
		|----algorithm.py
        |----network.py
        |----tool_box.py
        |----utils.py                   #our methods
		
```

**If all requirements are satisfied**, the results can be obtianed by running `submit_test.py`directly. 